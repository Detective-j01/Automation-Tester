import Page from "../Page/page.ts";

export const SELECTORS = {
  ANDROID: {
    email: `android=${'new UiSelector().text("email@address.com")'}`,
    password: `android=${'new UiSelector().text("Must be atleast 6 characters")'}`,
    btnLogin: `android=${'new UiSelector().resourceId("button")'}`,
    btnPermission:
      '//android.widget.Button[@resource-id="com.android.permissioncontroller:id/permission_allow_button"]',
    loginSuccessMessage: `android=${'new UiSelector().text("Login Success")'}`,
    dashboardTextMessage: `android=${'new UiSelector().text("Dashboard")'}`,
    invalidLoginMessage: `android=${'new UiSelector().description("Invalid email/password")'}`,
    // invalidLoginMessage:
    //   '//android.widget.TextView[@text="Invalid email/password"]',
    loginText: `android=${'new UiSelector().text("Log In")'}`,
    projectName:
      '(//android.widget.EditText[@resource-id="text-input-flat"])[1]',
    projectSiteAddress: `android=${'new UiSelector().text("Enter Location")'}`,
    siteAddressDropdown:
      '//android.widget.FrameLayout[@resource-id="android:id/content"]/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.HorizontalScrollView/android.view.ViewGroup',
    // `android=${'new UiSelector().className("android.view.ViewGroup").instance(21)'}`,
    //new UiSelector().className("android.view.ViewGroup").instance(23)
    currencyDropdown: `android=${'new UiSelector().className("android.widget.EditText").instance(2)'}`,
    selectUSD: `android=${'new UiSelector().description("USD")'}`,
    createProjectBtn: `android=${'new UiSelector().description("Create Project")'}`,
    projectInfoMsg: `android=${'new UiSelector().text("Project info")'}`,
    projectBudget:
      '(//android.widget.EditText[@resource-id="text-input-flat"])[2]',
    projectStartDateMsg: `android=${'new UiSelector().text("Project Start Date")'}`,
    projectDeadlineMsg: `android=${'new UiSelector().text("Project Deadline")'}`,
    projectStartDatePopUp:
      '//android.widget.FrameLayout[@resource-id="android:id/content"]/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup/android.widget.TextView',
    projectStartDateBtn: `android=${'new UiSelector().resourceId("icon-button-container").instance(0)'}`,
    projectStartDate:
      '//android.widget.EditText[@resource-id="text-input-flat"]',
    projectDeadlinePopup:
      '//android.widget.FrameLayout[@resource-id="android:id/content"]/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup[4]/android.view.ViewGroup/android.widget.TextView',
    projectEndDateBtn: `android=${'new UiSelector().resourceId("icon-button-container").instance(0)'}`,
    projectDeadline:
      '//android.widget.EditText[@resource-id="text-input-flat"]',
    InvalidBugetMsg: `android=${'new UiSelector().description("Invalid Budget")'}`,
    projectCreatedMsg: `android=${'new UiSelector().text("Project create successfully")'}`,
    projectCancelBtn: `android=${'new UiSelector().text("Cancel")'}`,
    projectSuccessDialog: `android=${'new UiSelector().description("Project create successfully")'}`,
    projectInvalidMsg: `android=${'new UiSelector().description("Invalid Date")'}`,
    createProjectLabel: `android=${'new UiSelector().text("Create Project")'}`,
    projectSameErrorMsg: `android=${'new UiSelector().text("Project Start Date can not be greater than Project Deadline.")'}`,
    selectEUR: `android=${'new UiSelector().description("EUR")'}`,
    selectZAR: `android=${'new UiSelector().description("ZAR")'}`,
  },
  //   IOS: {},
};

class DashboardPage extends Page {
  public async inputProjectName(projectName: string) {
    return driver.isAndroid
      ? await this.setElementInputValue(
          SELECTORS.ANDROID.projectName,
          projectName
        )
      : driver.isIOS;
  }

  public async getProjectDialog() {
    return driver.isAndroid
      ? await this.isElementDisplayed(SELECTORS.ANDROID.projectSuccessDialog)
      : driver.isIOS;
  }
  public async getCreateProjectLabel() {
    return driver.isAndroid
      ? await this.isElementDisplayed(SELECTORS.ANDROID.createProjectLabel)
      : driver.isIOS;
  }
  // public async inputProjectSiteAddress(projectName: string) {
  //   return driver.isAndroid
  //     ? (await this.clickElement(SELECTORS.ANDROID.projectSiteAddress),
  //       await this.addElementInputValue(
  //         SELECTORS.ANDROID.projectSiteAddress,
  //         projectName
  //       ),
  //       await browser.pause(4000))
  //     : driver.isIOS;
  // }
  // public async inputProjectSiteAddress(projectName: string) {
  //   if (driver.isAndroid) {
  //     // Click the address field
  //     await this.clickElement(SELECTORS.ANDROID.projectSiteAddress);

  //     // Wait for the field to be focused
  //     await browser.pause(1000); // You can adjust this timing based on the actual behavior

  //     // Clear the field (optional) and then add the value
  //     await this.addElementInputValue(
  //       SELECTORS.ANDROID.projectSiteAddress,
  //       projectName
  //     );
  //   }
  // }
  // public async inputProjectSiteAddress(projectName: string) {
  //   if (driver.isAndroid) {
  //     // Click the address field to focus on it
  //     await this.clickElement(SELECTORS.ANDROID.projectSiteAddress);

  //     // Wait for the field to be focused
  //     await browser.pause(1000); // Adjust based on actual behavior

  //     // Type each character one by one and wait after each keystroke
  //     for (const letter of projectName) {
  //       // Add the letter to the field
  //       await this.addElementInputValue(
  //         SELECTORS.ANDROID.projectSiteAddress,
  //         letter
  //       );

  //       // Wait for a short period to simulate a natural typing pace
  //       await browser.pause(300); // Adjust the timing as necessary
  //     }

  //     // Optionally, ensure the keyboard stays open
  //     // This might depend on your specific implementation and application behavior
  //     await driver.pressKeyCode(66); // This simulates pressing the 'Enter' key, adjust if needed
  //   }
  // }
  public async inputProjectSiteAddress(projectName: string) {
    if (driver.isAndroid) {
      // Click the address field to focus on it
      await this.clickElement(SELECTORS.ANDROID.projectSiteAddress);

      // Wait for the field to be focused
      await browser.pause(1000); // Adjust based on actual behavior

      // Type each character one by one
      for (const letter of projectName) {
        // Add the letter to the field
        await this.addElementInputValue(
          SELECTORS.ANDROID.projectSiteAddress,
          letter
        );

        // Wait for a short period to simulate a natural typing pace
        await browser.pause(300); // Adjust the timing as necessary
      }
    }
  }

  public async selectSiteAddressDropDown() {
    return driver.isAndroid
      ? await this.clickElement(SELECTORS.ANDROID.siteAddressDropdown)
      : driver.isIOS;
  }
  public async selectCurrencyUSD() {
    return driver.isAndroid
      ? (await this.clickElement(SELECTORS.ANDROID.currencyDropdown),
        await this.clickElement(SELECTORS.ANDROID.selectUSD))
      : driver.isIOS;
  }

  public async selectCurrencyEUR() {
    return driver.isAndroid
      ? (await this.clickElement(SELECTORS.ANDROID.currencyDropdown),
        await this.clickElement(SELECTORS.ANDROID.selectEUR))
      : driver.isIOS;
  }
  public async selectCurrencyZAR() {
    return driver.isAndroid
      ? (await this.clickElement(SELECTORS.ANDROID.currencyDropdown),
        await this.clickElement(SELECTORS.ANDROID.selectZAR))
      : driver.isIOS;
  }

  public async inputProjectBudget(projectBudget: string) {
    return driver.isAndroid
      ? await this.setElementInputValue(
          SELECTORS.ANDROID.projectBudget,
          projectBudget
        )
      : driver.isIOS;
  }
  public async inputProjectBudgetFloat(projectBudget: string) {
    // Ensure the budget is in a decimal format
    const formattedBudget = Number(projectBudget).toFixed(2);

    return driver.isAndroid
      ? await this.setElementInputValue(
          SELECTORS.ANDROID.projectBudget,
          formattedBudget
        )
      : driver.isIOS;
  }
  public async getCreateProjectBtn() {
    return driver.isAndroid
      ? await (async () => {
          // Scroll to the Add User button
          const scrollableSelector =
            "new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(" +
            'new UiSelector().description("Create Project"))';
          await driver.$(`android=${scrollableSelector}`);

          // Click the Add User button
          return this.clickElement(SELECTORS.ANDROID.createProjectBtn);
        })()
      : driver.isIOS; // Add iOS logic here if needed
  }
  public async getProjectInfoMsg() {
    return driver.isAndroid
      ? await this.getElementText(SELECTORS.ANDROID.projectInfoMsg)
      : driver.isIOS;
  }
  public async getProjectStartDateMsg() {
    return driver.isAndroid
      ? await this.getElementText(SELECTORS.ANDROID.projectStartDateMsg)
      : driver.isIOS;
  }
  public async getProjectDeadlineMsg() {
    return driver.isAndroid
      ? await this.getElementText(SELECTORS.ANDROID.projectDeadlineMsg)
      : driver.isIOS;
  }
  public async getProjectStartDatePopUp() {
    return driver.isAndroid
      ? await this.clickElement(SELECTORS.ANDROID.projectStartDatePopUp)
      : driver.isIOS;
  }
  public async getProjectStartDateBtn() {
    return driver.isAndroid
      ? await this.clickElement(SELECTORS.ANDROID.projectStartDateBtn)
      : driver.isIOS;
  }
  public async getProjectStartDate(startDate: string) {
    return driver.isAndroid
      ? await this.setElementInputValue(
          SELECTORS.ANDROID.projectStartDate,
          startDate
        )
      : driver.isIOS;
  }
  public async getProjectDeadlinePopUp() {
    return driver.isAndroid
      ? await this.clickElement(SELECTORS.ANDROID.projectDeadlinePopup)
      : driver.isIOS;
  }

  public async getProjectEndDateBtn() {
    return driver.isAndroid
      ? await this.clickElement(SELECTORS.ANDROID.projectEndDateBtn)
      : driver.isIOS;
  }

  public async getProjectDeadline(deadline: string) {
    return driver.isAndroid
      ? await this.setElementInputValue(
          SELECTORS.ANDROID.projectDeadline,
          deadline
        )
      : driver.isIOS;
  }
  public async getInvalidBugetMsg() {
    return driver.isAndroid
      ? await this.getElementText(SELECTORS.ANDROID.InvalidBugetMsg)
      : driver.isIOS;
  }

  public async getProjectCreatedMsg() {
    if (driver.isAndroid) {
      await browser.pause(800); // Optional pause
      return this.getElementText(SELECTORS.ANDROID.projectCreatedMsg);
    } else if (driver.isIOS) {
      // iOS-specific logic
      return;
      // return this.getElementText(SELECTORS.IOS.projectCreatedMsg);
    }
    return undefined;
  }

  public async getProjectCancelBtn() {
    return driver.isAndroid
      ? await this.clickElement(SELECTORS.ANDROID.projectCancelBtn)
      : driver.isIOS;
  }
  public async getProjectInvalidMsg() {
    return driver.isAndroid
      ? await this.getElementText(SELECTORS.ANDROID.projectInvalidMsg)
      : driver.isIOS;
  }
  public async getProjectSameDateMsg() {
    return driver.isAndroid
      ? await this.getElementText(SELECTORS.ANDROID.projectSameErrorMsg)
      : driver.isIOS;
  }
}

export default new DashboardPage();
