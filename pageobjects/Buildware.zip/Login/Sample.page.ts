import { $ } from "@wdio/globals";

/**
 * Sub page containing specific selectors and methods for a specific page.
 */
class SamplePage {
  /**
   * Define selectors using getter methods.
   */
  get email() {
    return $(`android = ${'new UiSelector().text("email@address.com")'}`);
  }
  get password() {
    return $(
      `android = ${'new UiSelector().text("Must be atleast 6 characters")'}`
    );
  }
  get Loginbtn() {
    return $("~LOG IN");
  }
  async allowPermission() {
    return await $(
      '//android.widget.Button[@resource-id="com.android.permissioncontroller:id/permission_allow_button"]'
    );
  }
  async successMsg(): Promise<string> {
    const selector = 'new UiSelector().text("Login Success")';
    const successMessage = await $(`android=${selector}`);
    return await successMessage.getText();
  }
  async dashboardText(): Promise<string> {
    const selector = 'new UiSelector().text("Dashboard")';
    const dashPageText = await $(`android=${selector}`);
    return await dashPageText.getText();
  }
}

export default new SamplePage();
